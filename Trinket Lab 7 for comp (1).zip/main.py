# Exercise 3 - Guessing Game
# The computer will guess your number between 1 and 1000

print("Think of a number between 1 and 1000, and I will try to guess it!")
print("When I guess, respond with:")
print("  'h' if my guess is too high")
print("  'l' if my guess is too low")
print("  'c' if my guess is correct")

low = 1
high = 1000
guesses = 0

while True:
    guess = (low + high) // 2
    guesses += 1

    print(f"\nIs your number {guess}?")
    user_input = input("Enter 'h' (too high), 'l' (too low), or 'c' (correct): ").strip().lower()

    if user_input == 'c':
        print(f"\nNice! I guessed your number in {guesses} guesses.")
        break
    elif user_input == 'h':
        high = guess - 1
    elif user_input == 'l':
        low = guess + 1
    else:
        print("Invalid input, please type 'h', 'l', or 'c'.")
